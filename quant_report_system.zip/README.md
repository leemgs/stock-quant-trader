
# Quant Report Generator

## Usage
pip install -r requirements.txt
python report_generator.py

## Output
report.md 생성
